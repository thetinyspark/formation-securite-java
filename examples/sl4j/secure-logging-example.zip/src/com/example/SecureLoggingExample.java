package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SecureLoggingExample {

    private static final Logger logger =
            LoggerFactory.getLogger(SecureLoggingExample.class);

    public static void main(String[] args) {

        String username = "admin";
        String action = "login";

        logger.info("Application démarrée");
        logger.info("Utilisateur {} a effectué l'action {}", username, action);

        try {
            int result = 10 / 0;
        } catch (Exception e) {
            logger.error("Erreur lors du calcul", e);
        }
    }
}
