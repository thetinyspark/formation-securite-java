Secure Logging Example (Java)

Dépendances minimales :
- slf4j-api
- logback-classic

Structure :
- src/com/example/SecureLoggingExample.java
- resources/logback.xml

Compilation (exemple) :
javac -cp "lib/*" -d bin src/com/example/SecureLoggingExample.java

Exécution :
java -cp "lib/*;bin;resources" com.example.SecureLoggingExample
